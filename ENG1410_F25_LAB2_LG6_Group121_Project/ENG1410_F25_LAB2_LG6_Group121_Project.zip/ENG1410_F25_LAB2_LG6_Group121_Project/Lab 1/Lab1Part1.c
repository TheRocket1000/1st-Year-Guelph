#include <stdio.h>

int main(void){
    printf("C uses escape sequences for a variety of purposes.\n"
           "Some common ones are:\n"
           "\t\tto print double quotes \", use \\\"\n"
           "\t\tto print backslash \\, use \\\\\n"
           "\t\tto go to a new line, use \\n\n"
           "\tHowever to print the percentage sign %%, we use %%%%\n");
}